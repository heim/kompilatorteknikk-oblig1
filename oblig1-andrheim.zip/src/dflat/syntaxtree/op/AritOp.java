package dflat.syntaxtree.op;

public abstract class AritOp extends Op {

}

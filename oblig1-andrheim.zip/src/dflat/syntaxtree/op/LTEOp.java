package dflat.syntaxtree.op;

public class LTEOp extends RelOp {

	public String printAst(int indent) {
		return indentTabs(indent) + "<=";
	}

}

package dflat.syntaxtree.op;

import dflat.syntaxtree.Node;

public abstract class Op extends Node {
}

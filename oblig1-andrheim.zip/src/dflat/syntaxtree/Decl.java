package dflat.syntaxtree;

public abstract class Decl extends Node {
}

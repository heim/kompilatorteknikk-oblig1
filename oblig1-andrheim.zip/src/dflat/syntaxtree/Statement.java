package dflat.syntaxtree;

public abstract class Statement extends Expression {


}

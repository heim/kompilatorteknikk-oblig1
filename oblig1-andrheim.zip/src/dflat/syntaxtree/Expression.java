package dflat.syntaxtree;

public abstract class Expression extends Node {

	

}

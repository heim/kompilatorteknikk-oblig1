package dflat.syntaxtree;

public abstract class Literal extends Expression {

}

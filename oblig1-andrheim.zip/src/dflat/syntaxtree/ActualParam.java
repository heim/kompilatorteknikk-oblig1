package dflat.syntaxtree;

public abstract class ActualParam extends Node {
 
}

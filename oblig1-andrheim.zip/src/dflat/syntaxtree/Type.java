package dflat.syntaxtree;

public abstract class Type extends Node {


}
